import discord
from discord.ext import commands

intents = discord.Intents.all()
bot = commands.Bot(",", intents=intents)

#GER TIME
jubileu = "88 GER"
michael = "85 GER"
carlos = "84 Ger"
necus ="84 GER"
dudu ="83 GER"
gin =" 83 GER"
maxsuel ="83 GER"
taddei ="83 GER"
bitata ="82 GER"
jonas ="82 GER"
kepler ="82 GER"
macols ="82 GER"
shanks ="82 GER"
cadiony ="81 GER"
garrincha ="81 GER"
ardolf ="80 GER"
kadielvis ="80 GER"
tizil ="80 GER"
pazhuerto ="74 GER"

@bot.event
async def on_ready():
    print ("Ligou")
@bot.command()
async def gertimev2(ctx):
    await ctx.reply(
                  f"# GER TIME PES 2013 V2 \n"
                  "(Ultima Atualização: Dia 10/10/26)\n"
                   f"JUBILEU  = {jubileu}\n"
                   f"MICHAEL JACKSON = {michael}\n"
                   f"CARLOS YCÁRO = {carlos}\n"
                   f"NECUS = {necus}\n"
                   f"DUDU = {dudu}\n"
                   f"GIN GAGAMARU = {gin}\n"
                   f"MAXSUEL GUTTE = {maxsuel}\n"
                   f"TADDEI = {taddei}\n"
                   f"BITATA TECO = {bitata}\n"
                   f"JONAS VALIM = {jonas}\n"
                   f"KÉPLER LIMA = {kepler}\n"
                   f"MACOLS TULYIO = {macols}\n"
                   f"SHANKS = {shanks}\n"
                   f"CADIONY = {cadiony}\n"
                   f"GARRINCHA = {garrincha}\n"
                   f"ARDOLF HIITOS = {ardolf}\n"
                   f"KADIELVIS JOTA {kadielvis}\n"
                   f"TIZIL = {tizil}\n"
                   f"PAZHUERTO {pazhuerto}\n"
    )



bot.run("MTU1ODQ4MDU2MzM0ODk3MTU1MQ.GuT7nv.0KjGiuDmy45_9D7-TpMx8PkWRXXrjMEB5YTMZo")